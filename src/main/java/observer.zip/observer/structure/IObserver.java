package observer.structure;

public interface IObserver {
    void update(String msg);
}