package observer.example;

public interface IUser {
    void update(String msg,Video newVideo);
    String getPreferenciaCategoria();
}