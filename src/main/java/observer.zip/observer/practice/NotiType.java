package observer.practice;

public enum NotiType {
    PRECIOLLAMADA,
    PROMOCION,
    PREMIO,
    NOTICIA
}
